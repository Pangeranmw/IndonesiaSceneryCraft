<?php
  define('BASEURL', 'http://localhost/ISC/public');
  define('DBHOST','localhost');
  define('DBUSER','root');
  define('DBPASS','');
  define('DBNAME','indonesiascenerycraft2');
