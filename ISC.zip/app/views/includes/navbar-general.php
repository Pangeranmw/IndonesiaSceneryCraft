<nav 
    class="container mx-auto navbar navbar-expand-lg rounded-pill z-index-3 my-3 py-2 start-0 end-0 mx-4 navbar navbar-expand-md fixed-top navbar-fixed-top navbar-dark main-color"
>   
